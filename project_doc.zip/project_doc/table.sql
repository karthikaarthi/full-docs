create table user(
  id int primary key AUTO_INCREMENT,
  name varchar(30),
  contactNumber varchar(30),
  email varchar(30),
  password varchar(20),
  status varchar(30),
  role varchar(20),
  UNIQUE (email)
);

insert into user(name,contactNumber,email,password,status,role)values('Admin','123243545','royorew574@rencr.com','admin','true','admin');