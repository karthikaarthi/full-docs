const express = require("express");
const connection = require("./connection");
let cors = require("cors");
const userRoute = require("./routes/user")
const app = express();
 
app.use(cors())
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use('/user',userRoute);
// app.use()
module.exports = app;