const username = document.querySelector('#username')
const email = document.querySelector('#email')
const password = document.querySelector('#password')
const cpassword = document.querySelector('#cpassword')
const form = document.querySelector('#form')

form.addEventListener('submit',(e)=>{

    
   if(! validateInputs()){
    e.preventDefault()
   }
})

function validateInputs(){
    const usernameVal= username.value.trim()
    const emailVal= email.value.trim()
    const passwordVal= password.value.trim()
    const cpasswordVal= cpassword.value.trim()
    let success=true
    if(usernameVal===''){
        setError(username,'User name is required')
        success=false
    }
    else{
        setSuccess(username)
    }
    if(emailVal===''){
        setError(email,'Email is required')
        success=false
    }
    else if(!isEmailValid(emailVal)){
        setError(email,'Pls enter valid email')
        success=false
    }
    else{
        setSuccess(email)
    }
    if(passwordVal===''){
        setError(password,'Password is required')
        success=false
    }

    else if(passwordVal.length<8){
        setError(password,'Password is must be atleast 8 character')
        success=false
    }
    else{
        setSuccess(password)
    }
    if(cpasswordVal===''){
        setError(cpassword,'Confirm Password is required')
        success=false
    }

    else if(passwordVal!==cpasswordVal){
        setError(cpassword,'Confirm password is miss match')
        success=false
    }
    else{
        setSuccess(cpassword)
    }

    return success
}

// password - password is required
function setError(element,message){
    const inputGroup=element.parentElement;
    const error=inputGroup.querySelector('.error')
    error.innerHTML=message;
    inputGroup.classList.add('error')
    inputGroup.classList.remove('success')

}
 
function setSuccess(element){
    const inputGroup=element.parentElement;
    const error=inputGroup.querySelector('.error')
    error.innerHTML='';
    inputGroup.classList.add('success')
    inputGroup.classList.remove('error')

}
 
 

 function isEmailValid(email) {
    const emailRegexp = new RegExp(
      /^[a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1}([a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1})*[a-zA-Z0-9]@[a-zA-Z0-9][-\.]{0,1}([a-zA-Z][-\.]{0,1})*[a-zA-Z0-9]\.[a-zA-Z0-9]{1,}([\.\-]{0,1}[a-zA-Z]){0,}[a-zA-Z0-9]{0,}$/i
    )
  
    return emailRegexp.test(email)
  }
  














// let username=document.querySelector('#username')
// let email=document.querySelector('#email')
// let password=document.querySelector('#password')
// let cpassword=document.querySelector('#cpassword')
// let form = document.querySelector('#form')

// form.addEventListener('submit',(e)=>{
    
//     if(!validateInputs()){
//         e.preventDefault();
//     }
// })


// function validateInputs(){
//     let usernameVal = username.value.trim()
//     let emailVal = email.value.trim()
//     let passwordVal = password.value.trim()
//     let cpasswordVal = cpassword.value.trim()
//     let success =true
//     if(usernameVal===''){
//         setError(username,'User Name is required')
//         success=false
//     }

//     else
//         setSuccess(username)
    
//     if(emailVal===''){
//         setError(email,'Email is required')
//         success=false
//     }
//     else if(!isEmailValid(emailVal)){
//         setError(email,'pls enter valid email id');
//         success=false
//     }

//     else{
//         setSuccess(email)
//     }

//     if(passwordVal===''){
//         setError(password,'Password is required')
//         success=false
//     }

//     else if(passwordVal.length<8){
//         setError(password,'Password is must be less 8 character')
//         success=false
//     }

//     else{
//         setSuccess(password)
//     }

//     if(cpasswordVal===''){
//         setError(cpassword,'Confirm password is required')
//         success=false
//     }
//     else if(cpasswordVal!==passwordVal){
//         setError(cpassword,'Password is missmatch')
//         success=false
//     }
//     else{
//         setSuccess(cpassword)
//     }

//     return success;
// }

// function setError(element,message){
//     const inputGroup=element.parentElement;
//     const error=inputGroup.querySelector('.error')
//     error.innerHTML=message;
//     inputGroup.classList.add('error') 
//     inputGroup.classList.remove('success');
// }

// function setSuccess(element){
//     const inputGroup=element.parentElement;
//     const error=inputGroup.querySelector('.error')
//     error.innerHTML='';
//     inputGroup.classList.remove('error')
//     inputGroup.classList.add('success');
// }

// function isEmailValid(email) {
//     const emailRegexp = new RegExp(
//       /^[a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1}([a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1})*[a-zA-Z0-9]@[a-zA-Z0-9][-\.]{0,1}([a-zA-Z][-\.]{0,1})*[a-zA-Z0-9]\.[a-zA-Z0-9]{1,}([\.\-]{0,1}[a-zA-Z]){0,}[a-zA-Z0-9]{0,}$/i
//     )
  
//     return emailRegexp.test(email)
//   }
  