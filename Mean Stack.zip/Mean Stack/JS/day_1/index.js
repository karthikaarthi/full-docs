console.log("Welcome To Js");
console.log([12,43,56,78]);
console.table([12,43,56,78]);