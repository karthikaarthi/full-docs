// javascript (global) window object

// Top level objects

// Global scope

x=20
y=()=>3+4
// console.log(window.y())

// Browsing context

// window.history.pushState({},'hello','window.html')

// DOM Access

window.document.querySelector('h1').style.color='yellow';


// Timing Function(settimeout,setinterval)

// window.setTimeout(()=>console.log('window object'),2000)

// window.setInterval(()=>console.log('hello'),2000)
// Event handling

// window.addEventListener('resize',()=>console.log('resized'))

// Global methods and properties

// alert,confirm,sessionStorage,localStorage

// window.alert('hello')
window.confirm('hello')
// console.log(window)

