let button=document.querySelector('button');

let select =document.querySelectorAll('.Currency')
let input = document.querySelector('.input')
fetch('https://api.frankfurter.app/currencies')
.then(res=>res.json())
.then(res=>displayDropDown(res))


function displayDropDown(res){
  let curr=Object.entries(res)
  for(let i=0;i<curr.length;i++){
    let opt=`<option value="${curr[i][0]}">${curr[i][0]}</option>`
    select[0].innerHTML+=opt;
    select[1].innerHTML+=opt;
  }
}

button.addEventListener('click',()=>{
  console.log(true)
  let curr1=select[0].value
  let curr2=select[1].value
  let inputVal=input.value;
  if(curr1 == curr2){
    let para=document.createElement('p')
    para.innerHTML='Do not convert to same currency'
    document.querySelector('.box').appendChild(para)
  }
  convert(curr1,curr2,inputVal);
})



function convert(curr1,curr2,inputVal){
  const host = 'api.frankfurter.app';
  fetch(`https://${host}/latest?amount=${inputVal}&from=${curr1}&to=${curr2}`)
  .then(resp => resp.json())
  .then((data) => {
    let result=document.querySelector('.result')
    result.value=data.rates[curr2]

  });   
}















// let button=document.querySelector('button')
// let input = document.querySelector('.input')
// let select =document.querySelectorAll('.Currency')
// fetch("https://api.frankfurter.app/currencies")
// .then(res=>res.json())
// .then(res=>displayDropDown(res))

// function displayDropDown(res){
//     let curr=Object.entries(res)
//     for(let i=0;i<curr.length;i++){
//         let opt =`<option value=${curr[i][0]}>${curr[i][0]}</option>`
//         select[0].innerHTML +=opt;
//         select[1].innerHTML +=opt;
//         // console.log(curr[i][0])
//     }
// }

// button.addEventListener('click',()=>{
//     let curr1= select[0].value;
//     let curr2= select[1].value;
//     let inputVal=input.value;
//     console.log(curr1,curr2)
//     convert(curr1,curr2,inputVal);
    
// })

// function convert(curr1,curr2,inputVal){
//     const host = 'api.frankfurter.app';
//     fetch(`https://${host}/latest?amount=${inputVal}&from=${curr1}&to=${curr2}`)
//   .then(resp => resp.json())
//   .then((data) => {
//     document.querySelector('.result').value=data.rates[curr2]
//     console.log(data.rates[curr2])
//   });

// }







