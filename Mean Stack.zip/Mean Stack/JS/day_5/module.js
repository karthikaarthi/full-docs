class User{
    login(){
        print('You are logged in...')
    }
    hello(){
        console.log('hello')
    }
}


function logout(){
    print('you are logged out...');
}


function free(){
    print('You have free 100GB storage.......')
}

export default User
export {logout,free}