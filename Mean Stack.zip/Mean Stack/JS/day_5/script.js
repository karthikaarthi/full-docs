
import User from './module.js';
let user1 = new User()
user1.login();
