import { login as lin,logout as lout } from "./modules/Functions.js";
import T from './modules/Temp.js'
lin()
lout()
let temp1= new T()
temp1.temp()



