export function login(){
  console.log('You are logged in...')
}

 export function logout(){
  console.log('You are logged out')
}

// export {login,logout}
