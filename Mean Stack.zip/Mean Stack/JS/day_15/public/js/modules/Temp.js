export default class Temp {
  temp() {
    console.log("Temp is work ....");
  }
}