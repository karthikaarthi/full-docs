from tkinter import *
from tkinter import ttk
from module import Databases
db=Databases("students_m")
root=Tk()
root.title('Student Management System')
root.state('zoomed')
name=StringVar()
age=StringVar()
email=StringVar()
doj=StringVar()
gender=StringVar()
contact=StringVar()
address=StringVar()
root.config(bg='#2c3e50')
# Entries frame

entries_frame=Frame(root,bg='#535c68')
entries_frame.pack(side=TOP,fill=X)

# heading
def displayAll():
    tv.delete(*tv.get_children())
    for row in db.showData():
        tv.insert("",END,values=row)
def add_student():
    if 

def update_student():
    pass

def clear_student():
    name.set('')
    age.set('')
    email.set('')
    doj.set('')
    contact.set('')
    gender.set('')
    address.set('')
    entryAddress.delete(1.0,END)


def delete_student():
    pass
title=Label(entries_frame,text='Student Management System',font=('calibri',25,'bold'),bg='#535c68',fg='white')
title.grid(row=0,columnspan=2,padx=20,pady=20,sticky='w')

lblName=Label(entries_frame,text='Name',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblName.grid(row=1,column=0,padx=10,pady=10,sticky='w')

entryName=Entry(entries_frame,textvariable=name,font=('Calibri',16),width=20)
entryName.grid(row=1,column=1,padx=10,pady=10,sticky='w')


lblAge=Label(entries_frame,text='Age',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblAge.grid(row=1,column=2,padx=10,pady=10,sticky='w')
entryAge=Entry(entries_frame,textvariable=age,font=('Calibri',16),width=20)
entryAge.grid(row=1,column=3,padx=10,pady=10,sticky='w')


lblDoj=Label(entries_frame,text='Date Of Joining',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblDoj.grid(row=2,column=0,padx=10,pady=10,sticky='w')
entryDoj=Entry(entries_frame,textvariable=doj,font=('Calibri',16),width=20)
entryDoj.grid(row=2,column=1,padx=10,pady=10,sticky='w')


lblEmail=Label(entries_frame,text='Email',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblEmail.grid(row=2,column=2,padx=10,pady=10,sticky='w')
entryEmail=Entry(entries_frame,textvariable=email,font=('Calibri',16),width=20)
entryEmail.grid(row=2,column=3,padx=10,pady=10,sticky='w')


lblGender=Label(entries_frame,text='Gender',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblGender.grid(row=3,column=0,padx=10,pady=10,sticky='w')
comboGender=ttk.Combobox(entries_frame,textvariable=gender,font=('Calibri',16),width=15,state='readonly')
comboGender['values']=('Female','Male')
comboGender.grid(row=3,column=1,padx=10,pady=10,sticky='w')


lblContact=Label(entries_frame,text='Contact No',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lblContact.grid(row=3,column=2,padx=10,pady=10,sticky='w')
entryContact=Entry(entries_frame,textvariable=contact,font=('Calibri',16),width=20)
entryContact.grid(row=3,column=3,padx=10,pady=10,sticky='w')


lbladdress=Label(entries_frame,text='Address',font=('calibri',18,'bold'),bg='#535c68',fg='white')
lbladdress.grid(row=4,column=0,padx=10,pady=10,sticky='w')
entryAddress=Text(entries_frame,font=('Calibri',16),width=50,height=5)
entryAddress.grid(row=4,column=1,padx=10,pady=10,sticky='w',columnspan=2)

btnFrame=Frame(entries_frame,bg='#ECDFCC')
btnFrame.grid(row=5,column=0,padx=10,pady=10,sticky='w',columnspan=4)

btnAdd=Button(btnFrame,text='Add Student',font=('Calibri',16),width=20,bg='#005B41',fg='white',bd=0,command=add_student)
btnAdd.grid(row=0,column=0,padx=10,pady=10,sticky='w')

btnUpdate=Button(btnFrame,text='Update Student',font=('Calibri',16),width=20,bg='#313866',fg='white',bd=0,command=update_student)
btnUpdate.grid(row=0,column=1,padx=10,pady=10,sticky='w')

btnClear=Button(btnFrame,text='Clear Students',font=('Calibri',16),width=20,bg='#FF5B00',fg='white',bd=0,command=clear_student)
btnClear.grid(row=0,column=2,padx=10,pady=10,sticky='w')

btnDelete=Button(btnFrame,text='Delete Student',font=('Calibri',16),width=20,bg='#990000',fg='white',bd=0,command=add_student)
btnDelete.grid(row=0,column=3,padx=10,pady=10,sticky='w')


#Table Frame

treeFrame=Frame(root,bg='#3C3D37')
treeFrame.place(x=0,y=485,width=1050,height=500)
style=ttk.Style()
style.configure('mystyle.Treeview',font=('Calibri',18),rowheight=50)


style=ttk.Style()
style.configure('mystyle.Treeview.Heading',font=('Calibri',20),rowheight=50)

tv=ttk.Treeview(treeFrame,columns=(1,2,3,4,5,6,7,8),style='mystyle.Treeview')
tv.heading('1',text='Id')
tv.column('1',width=30)
tv.heading('2',text='Name')
tv.column('2',width=100)

tv.heading('3',text='Age')
tv.column('3',width=50)

tv.heading('4',text='D,O.J')
tv.column('4',width=50)

tv.heading('5',text='Email')
tv.column('5',width=80)

tv.heading('6',text='Gender')
tv.column('6',width=50)

tv.heading('7',text='Contact')
tv.column('7',width=90)

tv.heading('8',text='Address')
tv.column('8',width=140)

tv['show']='headings'

tv.pack(fill=X)


displayAll()
displayAll()

root.mainloop()