import mysql.connector
from tkinter import *

class Databases:
    def __init__(self,db):
        self.con=mysql.connector.connect(host='localhost',user='root',password='root',database=db)
        self.res=self.con.cursor()
        self.res.execute('create table if not exists students(id int not null primary key auto_increment,name varchar(30) ,age int ,doj date,email varchar(30),gender varchar(30),contact varchar(30),address varchar(30))')
        self.con.commit()
        
    def insert(self,name,age,doj,email,gender,contact,address):
        self.res.execute('insert into students (name,age,doj,email,gender,contact,address) values (%s,%s,%s,%s,%s,%s,%s)',(name,age,doj,email,gender,contact,address))
        self.con.commit()
    
    def update(self,name,age,doj,email,gender,contact,address,id):
        self.res.execute('update students set name=%s,age=%s,doj=%s,email=%s,gender=%s,contact=%s,address=%s where id=%s',(name,age,doj,email,gender,contact,address,id))
        self.con.commit()
        
    def delete(self,id):
        self.res.execute('delete from students where id=%s',(id,))
        self.con.commit()
        
    def showData(self):
        self.res.execute('select * from students')
        result=self.res.fetchall()
        return(result)
    
        
        
        
                                    