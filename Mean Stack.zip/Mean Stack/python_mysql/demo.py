import mysql.connector
from tabulate import tabulate

con=mysql.connector.connect(
    host='localhost',
    user='root',
    password='root',
    database='python_db'
    )

def insert (name,age,city):
    res=con.cursor()
    res.execute('insert into users (name,age,city) values(%s,%s,%s)',(name,age,city))
    con.commit()


def update(name,age,city,id):
    res=con.cursor()
    res.execute('update users set name=%s,age=%s,city=%s where id=%s',(name,age,city,id))
    con.commit()


def delete (id):
    res=con.cursor()
    res.execute('delete from users where id=%s',(id,))
    con.commit()


def select():
    res=con.cursor()
    res.execute('select * from users')
    result=res.fetchall()
    print(tabulate(result,headers=['Id','Name','Age','City']))



while(True):
    print('1. Insert')
    print('2. Update')
    print('3. Select')
    print('4. Delete')
    print('5. Exit')
    choice=eval(input('Enter your choice: '))
    
    if(choice == 1):
        name=eval(input('Name: '))
        age=eval(input('Age: '))
        city=eval(input('City: '))
        insert(name,age,city)
        
    elif(choice == 2):
        name=eval(input('Name: '))
        age=eval(input('Age: '))
        city=eval(input('City: '))
        id=eval(input('Id: '))
        update(name,age,city,id)
        
    elif(choice == 3):
        select()
        
    elif(choice == 4):
        id=eval(input('Id: '))
        delete(id)
        
    elif(choice == 5):
        quit()
        
    else:
        print('Your input should be 1 to 5...')

        

        
        
    
