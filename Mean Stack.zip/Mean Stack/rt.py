#int

a=2352375238763
print(type(a))

#float
a=2.2836587634 #-> float datatype
print(type(a))

#char

a="saipriya"
print(type(a))

#complex
a=2+3j
print(type(a))

#bool
a=3
b=5
c=a>b
print(type(c))

#none
a=None
print(type(a))

#list
l=[1,2,3,4,5]
print(type(l))

#set
s={2,3,4,5}
print(type(s))

#tuple
a=(2,3,4,5)
print(type(a))

#dict
d={'name':'surya','id':34543,'class':'c'}
print(type(d))




